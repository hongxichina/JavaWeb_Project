package top.hxcn.hotelmanage.signup.service;

import top.hxcn.hotelmanage.signup.dao.UserDAO;
import top.hxcn.hotelmanage.signup.entity.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // 注册新用户
    public boolean register(User user) {
        // 首先检查用户名是否已存在
        if (!userDAO.checkUsernameExists(user.getUsername())) {
            // 如果用户名不存在，添加新用户
            userDAO.addUser(user);
            return true; // 注册成功
        } else {
            // 用户名已存在，注册失败
            return false;
        }
    }
}
