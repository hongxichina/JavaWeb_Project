package top.hxcn.hotelmanage.signup.dao;

import top.hxcn.hotelmanage.signup.entity.User;
import top.hxcn.hotelmanage.signup.utils.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    // 添加新用户
    public void addUser(User user) {
        try (Connection conn = DBUtils.getConnection()) {
            String sql = "INSERT INTO user (username, password, identity) VALUES (?, ?, 'user')";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPassword());
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 检查用户名是否存在
    public boolean checkUsernameExists(String username) {
        try (Connection conn = DBUtils.getConnection()) {
            String sql = "SELECT COUNT(*) FROM user WHERE username = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1) > 0;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
