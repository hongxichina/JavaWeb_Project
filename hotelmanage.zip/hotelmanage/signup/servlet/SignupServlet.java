package top.hxcn.hotelmanage.signup.servlet;

import top.hxcn.hotelmanage.signup.entity.User;
import top.hxcn.hotelmanage.signup.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        boolean registrationSuccess = userService.register(user);

        if (registrationSuccess) {
            // 注册成功，重定向到登录页面或注册成功页面
            response.sendRedirect("index.jsp");
        } else {
            // 注册失败，可能是由于用户名已存在
            // 可以设置一个属性来告知用户注册失败的原因
            request.setAttribute("errorMessage", "用户名已存在，请选择其他用户名");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
}
