package top.hxcn.hotelmanage.login.servlet;

import top.hxcn.hotelmanage.login.entity.User;
import top.hxcn.hotelmanage.login.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login") // 这里的 "/login" 是 Servlet 的访问路径
public class LoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 从请求中获取用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 调用 UserService 的 login 方法进行用户验证
        User user = userService.login(username, password);

        if (user != null) {
            // 用户验证成功，将用户信息保存到会话
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // 根据用户身份重定向到不同的页面
            if ("admin".equals(user.getIdentity())) {
                response.sendRedirect("loginsuccessadmin.jsp");
            } else {
                response.sendRedirect("loginsuccessuser.jsp");
            }
        } else {
            // 用户验证失败，重定向回登录页面
            response.sendRedirect("index.jsp");
        }
    }
}
