package top.hxcn.hotelmanage.login.service;

import top.hxcn.hotelmanage.login.dao.UserDAO;
import top.hxcn.hotelmanage.login.entity.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // 实现登录功能
    public User login(String username, String password) {
        // 调用DAO层的方法来验证用户名和密码
        return userDAO.getUserByUsernameAndPassword(username, password);
    }

    // 如果需要，可以添加更多与用户相关的业务逻辑方法
    // 例如注册、更新用户信息等
}

