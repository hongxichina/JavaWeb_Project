package top.hxcn.hotelmanage.login.dao;

import top.hxcn.hotelmanage.login.entity.User;
import top.hxcn.hotelmanage.login.utils.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    public User getUserByUsernameAndPassword(String username, String password) {
        User user = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            String sql = "SELECT * FROM user WHERE username = ? AND password = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setIdentity(rs.getString("identity"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 调用DBUtils关闭资源
            DBUtils.close(conn, ps, rs);
        }

        return user;
    }
}
