package top.hxcn.hotelmanage.admin.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet(name = "AdminServlet", urlPatterns = {"/AdminServlet"})
public class AdminServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        String page = "";
        switch (action) {
            case "楼层管理":
                page = "floorManagement.jsp";
                break;
            case "入住管理":
                page = "CheckInManagement.jsp";
                break;
            case "房型管理":
                page = "roomTypeManagement.jsp";
                break;
            case "客户管理":
                page = "customerManagement.jsp";
                break;
            case "预订列表":
                page = "bookingLists.jsp";
                break;
            case "营业统计":
                page = "businessStatistics.jsp";
                break;
            case "房间管理":
                page = "roomManagement.jsp";
                break;
            default:
                page = "index.jsp"; // 默认页面，可以根据需要更改
                break;
        }

        request.getRequestDispatcher(page).forward(request, response);
    }
}
