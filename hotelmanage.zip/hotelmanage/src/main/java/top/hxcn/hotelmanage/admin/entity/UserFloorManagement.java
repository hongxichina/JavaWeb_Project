package top.hxcn.hotelmanage.admin.entity;

public class UserFloorManagement {
    private int id;
    private String room_image;
    private String room_number;
    private String room_type;

    public UserFloorManagement() {
    }

    private String floor;

    public UserFloorManagement(int id, String room_image, String room_number, String room_type, String floor, String status, String room_facilities) {
        this.id = id;
        this.room_image = room_image;
        this.room_number = room_number;
        this.room_type = room_type;
        this.floor = floor;
        this.status = status;
        this.room_facilities = room_facilities;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoom_image() {
        return room_image;
    }

    public void setRoom_image(String room_image) {
        this.room_image = room_image;
    }

    public String getRoom_number() {
        return room_number;
    }

    public void setRoom_number(String room_number) {
        this.room_number = room_number;
    }

    public String getRoom_type() {
        return room_type;
    }

    public void setRoom_type(String room_type) {
        this.room_type = room_type;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRoom_facilities() {
        return room_facilities;
    }

    public void setRoom_facilities(String room_facilities) {
        this.room_facilities = room_facilities;
    }

    private String status;
    private String room_facilities;
}
