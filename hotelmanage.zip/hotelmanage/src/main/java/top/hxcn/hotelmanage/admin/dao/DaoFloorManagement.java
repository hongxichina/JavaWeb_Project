package top.hxcn.hotelmanage.admin.dao;

import top.hxcn.hotelmanage.admin.entity.UserFloorManagement;
import top.hxcn.hotelmanage.signup.utils.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DaoFloorManagement {
    public List<UserFloorManagement> getAllFloorManagement() {
        List<UserFloorManagement> resultList = new ArrayList<>();
        String sql = "SELECT * FROM floormanagement";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                UserFloorManagement floorManagement = new UserFloorManagement();
                floorManagement.setId(rs.getInt("id"));
                floorManagement.setRoom_image(rs.getString("room_image"));
                floorManagement.setRoom_number(rs.getString("room_number"));
                floorManagement.setRoom_type(rs.getString("room_type"));
                floorManagement.setFloor(rs.getString("floor"));
                floorManagement.setStatus(rs.getString("status"));
                floorManagement.setRoom_facilities(rs.getString("room_facilities"));
                resultList.add(floorManagement);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultList;
    }

    // 新添加的删除房间的方法
    public boolean deleteRoom(int id) {
        String sql = "DELETE FROM floormanagement WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
