package top.hxcn.hotelmanage.admin.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import top.hxcn.hotelmanage.admin.dao.DaoFloorManagement;

import java.io.IOException;

@WebServlet("/DeleteRoomServlet")
public class DeleteRoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int roomId = Integer.parseInt(request.getParameter("id"));
        System.out.println(roomId);
        DaoFloorManagement dao = new DaoFloorManagement();

        if (dao.deleteRoom(roomId)) {
            response.getWriter().write("success");
        } else {
            response.getWriter().write("error");
        }
    }
}
